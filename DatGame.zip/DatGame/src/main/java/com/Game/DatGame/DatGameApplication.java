package com.Game.DatGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatGameApplication.class, args);
	}

}
