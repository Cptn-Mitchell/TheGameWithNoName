package com.Game.DatGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
